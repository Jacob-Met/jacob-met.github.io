import fs from 'node:fs';import path from 'node:path';import crypto from 'node:crypto';import {DatabaseSync} from 'node:sqlite';
const root='C:\\Users\\minec\\hamon-site-hook-c77045b4',repo=path.join(root,'repo'),hub='C:\\Users\\minec\\AppData\\Local\\Hamon\\hubtwo\\state';
const expected=JSON.parse(fs.readFileSync(path.join(root,'canonical-tree.json'),'utf8'));
const db=new DatabaseSync(path.join(hub,'worker-hub.sqlite3'),{readOnly:true});db.exec('PRAGMA query_only=ON');
const record=JSON.parse(db.prepare('SELECT result FROM tasks WHERE task_id=?').get('wt_d629a21f0a75496c843c51a1').result);db.close();
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),blob=b=>crypto.createHash('sha1').update(Buffer.from('blob '+b.length+'\0')).update(b).digest('hex');
const manifest={schema:'hamon.site.windows-source-intake.v1',receivedUtc:new Date().toISOString(),repository:expected.repository,head:expected.head,tree:expected.tree.sha,task:'wt_d629a21f0a75496c843c51a1',attempt:record.attempt_id,files:[]};
if(expected.tree.truncated)throw new Error('Incomplete canonical source tree');
for(const f of expected.tree.tree.filter(f=>f.type==='blob')){
 if(f.path.split('/').some(p=>p==='..'||p==='.git')||path.isAbsolute(f.path))throw new Error('Unsafe canonical intake path');
 const a=record.artifacts.find(a=>a.path==='out/site-source/'+f.path);if(!a)throw new Error('Qualified custody source absent: '+f.path);
 const original=path.resolve(a.custody_path);if(!original.startsWith(path.resolve(hub,'worker-artifacts')+path.sep))throw new Error('Not in local custody');
 const bytes=fs.readFileSync(original);
 if(sha(bytes)!==a.sha256||bytes.length!==a.size||blob(bytes)!==f.sha||bytes.length!==f.size)throw new Error('Native/canonical identity mismatch: '+f.path);
 const target=path.join(repo,f.path);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,bytes,{flag:'wx'});
 manifest.files.push({path:f.path,mode:f.mode,bytes:bytes.length,sha256:sha(bytes),gitBlob:blob(bytes)});
}
fs.writeFileSync(path.join(root,'source-manifest.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({head:manifest.head,tree:manifest.tree,files:manifest.files.length,bytes:manifest.files.reduce((n,f)=>n+f.bytes,0),manifestSha256:sha(fs.readFileSync(path.join(root,'source-manifest.json'))),credentialsOrOriginalGitMetadataCopied:false}));
