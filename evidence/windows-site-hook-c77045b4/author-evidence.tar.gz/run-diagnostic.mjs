import fs from 'node:fs';import path from 'node:path';import {spawnSync} from 'node:child_process';
const root='C:\\Users\\minec\\hamon-site-hook-c77045b4',python='C:\\Users\\minec\\AppData\\Local\\Hamon\\hubtwo\\runtime\\python-3.13.15\\python.exe';
const env={...process.env,PATH:[path.join(root,'bin'),'C:\\Program Files\\Git\\usr\\bin','C:\\Program Files\\Git\\cmd',path.dirname(python),process.env.PATH].join(';'),TEMP:path.join(root,'temp with spaces'),TMP:path.join(root,'temp with spaces'),PYTHONDONTWRITEBYTECODE:'1'};
const r=spawnSync(python,['-B',path.join(root,'diagnose-hook.py')],{env,cwd:root,encoding:'utf8',timeout:30000});
console.log(JSON.stringify({status:r.status,signal:r.signal,error:r.error?.message??null,stdout:r.stdout,stderr:r.stderr}));process.exitCode=r.status??1;
