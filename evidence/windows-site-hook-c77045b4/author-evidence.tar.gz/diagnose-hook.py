import hashlib, json, os, shutil, subprocess, sys
from pathlib import Path
root = Path(__file__).resolve().parent
sys.path.insert(0, str(root / "baseline" / "source"))
import test_site
results = []
for label in ["system_defaults_no_attributes", "canonical_attributes", "core_autocrlf_false"]:
    case = test_site.PrecommitHookTests("test_staged_source_with_rebuilt_docs_passes")
    case.setUp()
    try:
        if label == "canonical_attributes":
            shutil.copy2(root / "baseline" / ".gitattributes", case.work / ".gitattributes")
            case.git("add", ".gitattributes")
        if label == "core_autocrlf_false":
            case.git("config", "core.autocrlf", "false")
        case.edit_content()
        case.rebuild()
        case.git("add", "source/content.json", "docs")
        before = case.git("status", "--porcelain").stdout
        index_before = hashlib.sha256((case.work / ".git" / "index").read_bytes()).hexdigest()
        actual = subprocess.run(["sh", ".githooks/pre-commit"], cwd=case.work, capture_output=True, text=True)
        index_after = hashlib.sha256((case.work / ".git" / "index").read_bytes()).hexdigest()
        after = case.git("status", "--porcelain").stdout
        original = (case.work / ".githooks" / "pre-commit").read_text(encoding="utf-8")
        diagnostic = original.replace("trap 'rm -rf \"$SCRATCH\"' EXIT INT TERM", "trap ':' EXIT INT TERM").replace('diff -qr "$SCRATCH/staged/docs" "$SCRATCH/checked-site" >/dev/null 2>&1', 'diff -qr "$SCRATCH/staged/docs" "$SCRATCH/checked-site"')
        diag = root / "evidence" / (label + "-diagnostic.sh")
        diag.write_text(diagnostic, encoding="utf-8", newline="\n")
        prior = set(Path(os.environ["TEMP"]).iterdir())
        traced = subprocess.run(["sh", "-x", str(diag)], cwd=case.work, capture_output=True, text=True)
        new_dirs = [p for p in Path(os.environ["TEMP"]).iterdir() if p not in prior and p.is_dir()]
        comparisons = []
        for scratch in new_dirs:
            staged, fresh = scratch / "staged" / "docs", scratch / "checked-site"
            for name in ["index.html", "style.css", "build-manifest.json", "favicon.ico"]:
                first, second = staged / name, fresh / name
                row = {"scratch":str(scratch), "file":name, "staged_exists":first.exists(), "fresh_exists":second.exists()}
                if first.exists() and second.exists():
                    a,b=first.read_bytes(),second.read_bytes()
                    row.update({"staged_bytes":len(a),"fresh_bytes":len(b),"staged_crlf":a.count(b"\r\n"),"fresh_crlf":b.count(b"\r\n"),"equal":a==b,"equal_after_lf_normalization":a.replace(b"\r\n",b"\n")==b.replace(b"\r\n",b"\n")})
                comparisons.append(row)
        results.append({"case":label,"exact_hook_exit":actual.returncode,"exact_stderr":actual.stderr,"status_unchanged":before==after,"index_bytes_unchanged":index_before==index_after,"diagnostic_exit":traced.returncode,"diagnostic_stdout":traced.stdout,"diagnostic_stderr":traced.stderr,"comparisons":comparisons})
    finally:
        case.doCleanups()
(root / "evidence" / "diagnostic-results.json").write_text(json.dumps(results,indent=2)+"\n",encoding="utf-8")
print(json.dumps(results))
